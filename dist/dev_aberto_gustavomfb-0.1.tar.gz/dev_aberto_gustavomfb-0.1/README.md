# Aula-06
Pacote Hello desenvolvido em python
https://github.com/Insper/dev-aberto